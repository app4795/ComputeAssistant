package ntou.cs.java2014.Interface;
public interface Start{
	public void start();
}