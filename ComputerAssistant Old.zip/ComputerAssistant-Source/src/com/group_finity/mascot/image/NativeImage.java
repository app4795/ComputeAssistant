package com.group_finity.mascot.image;

public interface NativeImage {

}
