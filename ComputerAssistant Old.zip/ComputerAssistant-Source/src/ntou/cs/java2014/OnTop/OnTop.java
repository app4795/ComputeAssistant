package ntou.cs.java2014.OnTop;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import ntou.cs.java2014.Interface.BasisFrame;
import ntou.cs.java2014.Interface.Start;
public class OnTop extends BasisFrame implements Start {
	JTextArea ftextarea;
	public JScrollPane fscroll;
	public void createAndShowGUI(String title){
		super.createAndShowGUI(title);
		JScrollPane fscroll;
		ftextarea = new JTextArea();
		ftextarea.setRows(9);
		fscroll = new JScrollPane(ftextarea);
		fscroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		ftextarea.setColumns(15);
		ftextarea.setFont(new Font("", Font.BOLD, 20));
		ftextarea.setLineWrap(true);
		ftextarea.setBackground(new Color(222, 245, 129));
		fbsave.addMouseListener(new savebutton(frame,fbsave));
		fbre.setText("");
		masterp.add(fscroll,BorderLayout.CENTER);
		frame.pack();
		frame.setAlwaysOnTop(true);
		frame.setVisible(true);
	}
	public void start(){
		main("�u��");
	}
	public class savebutton extends BasisFrame.savebutton{
		public savebutton(JFrame f2temp, JLabel f2label){
			super(f2temp,f2label);
		}
		public void mouseReleased(MouseEvent e){
			ftextarea.selectAll();
			ftextarea.copy();
			fedit.setVisible(false);
			fedit.dispose();
		}
	}
}
